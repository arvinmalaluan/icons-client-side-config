if (window.localStorage.getItem("token")) {
  window.location.href =
    "http://127.0.0.1:5500/src/templates/home.template.html";
}

// else {
//   window.location.href = "http://127.0.0.1:5500/index.html";
// }
